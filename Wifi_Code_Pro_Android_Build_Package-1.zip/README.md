# Wifi Code Pro — RouterOS User Manager voucher app (source)

This is an updated Flutter source project for the user's MikroTik hAP ax S / RouterOS 7.25.2 setup.

## Implemented in this source
- Opens directly to Main Dashboard; no separate app login screen.
- Connects to RouterOS REST API using the RouterOS username/password entered on the Router page.
- Tests the connection by reading `/rest/system/resource` and `/rest/user-manager`.
- Reads User Manager users and profiles.
- Creates 6-digit numeric voucher users in `/user-manager/user`; username and password are the same.
- Optionally assigns a selected User Manager profile through `/user-manager/user-profile`.
- Reads active Hotspot sessions and shows voucher QR codes.
- Lists and deletes User Manager users.

## Important limitations
- QR currently encodes the voucher credentials as app data; it is not a payment QR and does not automatically log a phone into Hotspot.
- Reports are basic counts only. Payment collection, sales ledger, print layouts, PDF/CSV export, and secure credential storage are not implemented.
- The app does not fix the Router's existing Hotspot `INVALID` / `not allowed by device-mode` issue. Voucher records may be created while Hotspot login still fails.
- HTTP is enabled for LAN testing. HTTP Basic credentials are not encrypted. Use only on a trusted local network. For remote access, use WireGuard/VPN plus HTTPS with a trusted certificate. Do not expose REST/WebFig directly to the public internet.
- Use a dedicated RouterOS account with only the required `read,write,api,rest-api` policies; do not use the main admin account in production.
- Router connection credentials are held in app memory only and are not persisted by this starter implementation.

## RouterOS requirements
- User Manager enabled.
- RouterOS REST service enabled (`www` for LAN-only HTTP or `www-ssl` for HTTPS).
- REST user must have `read,write,api,rest-api` policies and access to the router from the phone's LAN/VPN.
- User Manager RADIUS and Hotspot profile must already be configured. Hotspot itself must be valid before voucher login can work.

## Build
Install Flutter SDK and Android SDK, then run:

```bash
flutter pub get
flutter analyze
flutter build apk --release
```

APK output: `build/app/outputs/flutter-apk/app-release.apk`.

This environment did not have the Flutter SDK available, so this source archive has not been compiled or device-tested here.
