# Wifi Code Pro — Android APK Build

ဒီ ZIP ထဲမှာ Flutter source project နဲ့ GitHub Actions build workflow ပါပါတယ်။ ဒီနေရာမှာ Flutter SDK မရှိတဲ့အတွက် APK ကို compile / device-test မလုပ်နိုင်သေးပါ။ GitHub ကနေ build လုပ်ပြီး APK ကိုရယူနိုင်ပါတယ်။

## APK ရယူရန် (ကွန်ပျူတာလိုအပ်သည်)

1. GitHub account ဝင်ပါ။
2. New repository တစ်ခုဖန်တီးပါ (ဥပမာ `wifi-code-pro`).
3. ဒီ ZIP ကို extract လုပ်ပြီး အထဲကဖိုင်အားလုံးကို repository ထဲ upload လုပ်ပါ။ `.github` folder ပါ upload ဖြစ်ရပါမယ်။
4. Repository ရဲ့ **Actions** tab ကိုဖွင့်ပါ။
5. `Build Android APK` workflow ကိုရွေးပြီး **Run workflow** ကိုနှိပ်ပါ။ `main` branch ပေါ် push လုပ်ရင်လည်း အလိုအလျောက် build ပါမယ်။
6. Build အောင်မြင်ပြီးရင် workflow run အောက်ဆုံး **Artifacts** မှ `Wifi-Code-Pro-APK` ကို download လုပ်ပါ။
7. ZIP ကိုဖြည်ပြီး `app-release.apk` ကို Android ဖုန်းထဲပို့ကာ install လုပ်ပါ။ Android က unknown apps ခွင့်ပြုရန် တောင်းလာနိုင်ပါတယ်။

## Router လုံခြုံရေးနှင့် ကန့်သတ်ချက်များ

- App က RouterOS REST API ကို အသုံးပြုပါတယ်။
- LAN အတွင်း စမ်းသပ်ရာမှာသာ HTTP ကိုသုံးပါ။ HTTP မှာ login အချက်အလက်တွေ encrypt မဖြစ်ပါ။
- အင်တာနက်ပေါ်ကို Router ရဲ့ REST/WebFig port ကို တိုက်ရိုက်မဖွင့်ပါနဲ့။ အဝေးကနေသုံးမယ်ဆိုရင် WireGuard VPN သုံးပါ။
- RouterOS မှာ `read,write,api,rest-api` လိုအပ်တဲ့ policy သာရှိတဲ့ သီးသန့် user တစ်ခုဖန်တီးပါ။ Main admin account မသုံးပါနဲ့။
- Hotspot `INVALID` / device-mode ပြဿနာ မပြေလည်သေးရင် Voucher user ဖန်တီးနိုင်ပေမယ့် Hotspot login မအောင်မြင်နိုင်ပါ။
- Build ပြီးတာနဲ့ Router အစစ်နဲ့ login / voucher create / delete / QR flow ကို စမ်းသပ်အတည်ပြုရပါမယ်။

## App အခြေခံလုပ်ဆောင်ချက်များ

- App Login မပါဘဲ Dashboard တန်းဝင်ခြင်း
- RouterOS REST API ချိတ်ဆက်စမ်းသပ်ခြင်း
- User Manager users / profiles ဖတ်ခြင်း
- ၆ လုံး Voucher username/password တူညီစွာ ထုတ်ခြင်း
- Profile ရွေးချယ်ခြင်း
- Active Hotspot sessions ကြည့်ခြင်း
- QR ပြခြင်း
- Voucher စာရင်းကြည့်ခြင်းနှင့် ဖျက်ခြင်း

QR သည် voucher credential ကို encode လုပ်ထားခြင်းသာဖြစ်ပြီး Payment QR မဟုတ်ပါ။ Sales, payment, PDF/CSV, print layout, secure credential storage မပါဝင်သေးပါ။
