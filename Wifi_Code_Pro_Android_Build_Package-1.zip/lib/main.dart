import 'dart:convert';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:qr_flutter/qr_flutter.dart';

void main() => runApp(const WifiCodeProApp());

class WifiCodeProApp extends StatelessWidget {
  const WifiCodeProApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Wifi Code Pro',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1769AA)),
          useMaterial3: true,
        ),
        home: const MainDashboard(),
      );
}

class RouterOsClient {
  RouterOsClient({required this.host, required this.username, required this.password, required this.https});

  final String host;
  final String username;
  final String password;
  final bool https;

  Uri _uri(String path) {
    final cleanHost = host.trim().replaceFirst(RegExp(r'^https?://'), '').replaceAll(RegExp(r'/$'), '');
    return Uri.parse('${https ? 'https' : 'http'}://$cleanHost/rest/$path');
  }

  Map<String, String> get _headers => {
        'Authorization': 'Basic ${base64Encode(utf8.encode('$username:$password'))}',
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      };

  Future<dynamic> _request(String method, String path, [Map<String, dynamic>? body]) async {
    final uri = _uri(path);
    late http.Response response;
    switch (method) {
      case 'GET':
        response = await http.get(uri, headers: _headers).timeout(const Duration(seconds: 12));
        break;
      case 'PUT':
        response = await http.put(uri, headers: _headers, body: jsonEncode(body ?? {})).timeout(const Duration(seconds: 12));
        break;
      case 'DELETE':
        response = await http.delete(uri, headers: _headers).timeout(const Duration(seconds: 12));
        break;
      default:
        throw Exception('Unsupported request');
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw Exception('RouterOS HTTP ${response.statusCode}: ${response.body.isEmpty ? response.reasonPhrase : response.body}');
    }
    if (response.body.trim().isEmpty) return null;
    return jsonDecode(response.body);
  }

  Future<Map<String, dynamic>> test() async {
    final resource = await _request('GET', 'system/resource');
    final um = await _request('GET', 'user-manager');
    final item = resource is List && resource.isNotEmpty ? Map<String, dynamic>.from(resource.first) : <String, dynamic>{};
    final settings = um is Map ? Map<String, dynamic>.from(um) : (um is List && um.isNotEmpty ? Map<String, dynamic>.from(um.first) : <String, dynamic>{});
    if (settings['enabled'] != 'true' && settings['enabled'] != 'yes') {
      throw Exception('RouterOS ချိတ်ဆက်ရပါပြီ၊ ဒါပေမဲ့ User Manager enabled မဖြစ်သေးပါ');
    }
    return item;
  }

  Future<List<Map<String, dynamic>>> users() async => _asList(await _request('GET', 'user-manager/user'));
  Future<List<Map<String, dynamic>>> profiles() async => _asList(await _request('GET', 'user-manager/profile'));
  Future<List<Map<String, dynamic>>> activeSessions() async => _asList(await _request('GET', 'ip/hotspot/active'));

  Future<void> addVoucher(String code, {String? profile}) async {
    await _request('PUT', 'user-manager/user', {
      'name': code,
      'password': code,
      'group': 'default',
      'shared-users': '1',
      'comment': 'Wifi Code Pro voucher',
    });
    if (profile != null && profile.isNotEmpty) {
      await _request('PUT', 'user-manager/user-profile', {'user': code, 'profile': profile});
    }
  }

  Future<void> deleteUser(String id) async => _request('DELETE', 'user-manager/user/$id');
}

List<Map<String, dynamic>> _asList(dynamic value) {
  if (value is List) return value.map((e) => Map<String, dynamic>.from(e as Map)).toList();
  return [];
}

class VoucherRecord {
  VoucherRecord(this.username, this.password);
  final String username;
  final String password;
}

class MainDashboard extends StatefulWidget {
  const MainDashboard({super.key});
  @override
  State<MainDashboard> createState() => _MainDashboardState();
}

class _MainDashboardState extends State<MainDashboard> {
  int _index = 0;
  final _host = TextEditingController(text: '192.168.1.1');
  final _user = TextEditingController(text: 'admin');
  final _password = TextEditingController();
  bool _https = false;
  bool _showPassword = false;
  bool _connected = false;
  bool _busy = false;
  String _connectionMessage = 'Router မချိတ်ရသေးပါ';
  RouterOsClient? _client;
  Map<String, dynamic> _resource = {};
  List<Map<String, dynamic>> _users = [];
  List<Map<String, dynamic>> _profiles = [];
  List<Map<String, dynamic>> _sessions = [];
  final List<VoucherRecord> _created = [];

  @override
  void dispose() {
    _host.dispose();
    _user.dispose();
    _password.dispose();
    super.dispose();
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _connect() async {
    if (_host.text.trim().isEmpty || _user.text.trim().isEmpty || _password.text.isEmpty) {
      _message('Router IP, Username, Password ဖြည့်ပါ');
      return;
    }
    setState(() { _busy = true; _connectionMessage = 'ချိတ်ဆက်နေသည်...'; });
    try {
      final client = RouterOsClient(host: _host.text, username: _user.text, password: _password.text, https: _https);
      final resource = await client.test();
      final users = await client.users();
      final profiles = await client.profiles();
      final sessions = await client.activeSessions();
      setState(() {
        _client = client;
        _resource = resource;
        _users = users;
        _profiles = profiles;
        _sessions = sessions;
        _connected = true;
        _connectionMessage = 'ချိတ်ဆက်ပြီး — ${resource['board-name'] ?? 'MikroTik'} / ${resource['version'] ?? ''}';
      });
      _message('MikroTik ချိတ်ဆက်မှု အောင်မြင်ပါပြီ');
    } catch (e) {
      setState(() { _connected = false; _client = null; _connectionMessage = 'ချိတ်ဆက်မှု မအောင်မြင်ပါ: $e'; });
      _message('မချိတ်ဆက်နိုင်ပါ: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _refresh() async {
    final client = _client;
    if (client == null) return;
    setState(() => _busy = true);
    try {
      final users = await client.users();
      final profiles = await client.profiles();
      final sessions = await client.activeSessions();
      setState(() { _users = users; _profiles = profiles; _sessions = sessions; });
    } catch (e) { _message('ပြန်လည်ရယူမှု မအောင်မြင်ပါ: $e'); }
    finally { if (mounted) setState(() => _busy = false); }
  }

  Future<void> _createVouchers(int count, String? profile) async {
    final client = _client;
    if (client == null) { _message('အရင်ဆုံး Router ချိတ်ပါ'); return; }
    if (_profiles.isEmpty && profile != null) { _message('User Manager မှာ Profile မရှိသေးပါ'); return; }
    setState(() => _busy = true);
    final random = Random.secure();
    final batch = <VoucherRecord>[];
    try {
      for (var i = 0; i < count; i++) {
        String code;
        var tries = 0;
        do {
          code = (100000 + random.nextInt(900000)).toString();
          tries++;
        } while ((_users.any((u) => u['name'] == code) || batch.any((v) => v.username == code)) && tries < 30);
        if (tries >= 30) throw Exception('Voucher code အသစ် မထုတ်နိုင်ပါ');
        await client.addVoucher(code, profile: profile);
        batch.add(VoucherRecord(code, code));
      }
      setState(() { _created.insertAll(0, batch); _users = [..._users, ...batch.map((v) => {'name': v.username, 'password': v.password})]; });
      _message('Voucher ${batch.length} ခု ထုတ်ပြီးပါပြီ');
    } catch (e) {
      _message('Voucher ထုတ်ရာတွင် အမှားရှိသည်: $e\nထုတ်ပြီးသားများကို User Manager မှာ စစ်ပါ');
      await _refresh();
    } finally { if (mounted) setState(() => _busy = false); }
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _homePage(), _voucherPage(), _usersPage(), _qrPage(), _routerPage(), _reportPage(),
    ];
    return Scaffold(
      appBar: AppBar(title: const Text('Wifi Code Pro'), actions: [
        IconButton(tooltip: 'Refresh', onPressed: _connected && !_busy ? _refresh : null, icon: const Icon(Icons.refresh)),
        IconButton(tooltip: 'Router', onPressed: () => setState(() => _index = 4), icon: const Icon(Icons.router)),
      ]),
      body: SafeArea(child: pages[_index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.confirmation_number_outlined), label: 'Voucher'),
          NavigationDestination(icon: Icon(Icons.people_outline), label: 'Users'),
          NavigationDestination(icon: Icon(Icons.qr_code_2), label: 'QR'),
          NavigationDestination(icon: Icon(Icons.router_outlined), label: 'Router'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Report'),
        ],
      ),
    );
  }

  Widget _homePage() => ListView(padding: const EdgeInsets.all(16), children: [
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Wifi Code Pro', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      const SizedBox(height: 6), Text(_connectionMessage),
      const SizedBox(height: 14), Wrap(spacing: 8, runSpacing: 8, children: [
        _metric('Vouchers', _users.length.toString(), Icons.confirmation_number),
        _metric('Active users', _sessions.length.toString(), Icons.people),
        _metric('Profiles', _profiles.length.toString(), Icons.speed),
      ]),
    ]))),
    const SizedBox(height: 12),
    _actionTile(Icons.add_card, 'Voucher ထုတ်ရန်', 'Voucher အသစ်များဖန်တီးမည်', () => setState(() => _index = 1)),
    _actionTile(Icons.people, 'Users', 'User Manager Voucher စာရင်း', () => setState(() => _index = 2)),
    _actionTile(Icons.qr_code_2, 'QR Code', 'နောက်ဆုံးထုတ်ထားသော Voucher QR', () => setState(() => _index = 3)),
    _actionTile(Icons.router, 'Router ချိတ်ရန်', 'MikroTik REST API ချိတ်ဆက်မှု', () => setState(() => _index = 4)),
    const SizedBox(height: 10),
    const Text('သတိပြုရန်: လက်ရှိ Hotspot INVALID ပြဿနာ မဖြေရှင်းရသေးပါက Voucher ဖန်တီးနိုင်သော်လည်း Wi-Fi Login မအောင်မြင်နိုင်သေးပါ။', style: TextStyle(color: Colors.deepOrange)),
  ]);

  Widget _metric(String label, String value, IconData icon) => SizedBox(width: 135, child: Card(child: Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon), const SizedBox(height: 5), Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)), Text(label)]))));

  Widget _actionTile(IconData icon, String title, String subtitle, VoidCallback onTap) => Card(child: ListTile(leading: Icon(icon), title: Text(title), subtitle: Text(subtitle), trailing: const Icon(Icons.chevron_right), onTap: onTap));

  Widget _voucherPage() => VoucherCreator(connected: _connected, busy: _busy, profiles: _profiles, onCreate: _createVouchers, created: _created);

  Widget _usersPage() => RefreshIndicator(onRefresh: _refresh, child: ListView(padding: const EdgeInsets.all(16), children: [
    Row(children: [const Expanded(child: Text('User Manager Users', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold))), IconButton(onPressed: _connected && !_busy ? _refresh : null, icon: const Icon(Icons.refresh))]),
    if (!_connected) const Text('အရင် Router ချိတ်ပါ'),
    ..._users.map((u) => Card(child: ListTile(leading: const Icon(Icons.confirmation_number), title: Text('${u['name'] ?? 'Unknown'}'), subtitle: Text('Group: ${u['group'] ?? 'default'}  •  Disabled: ${u['disabled'] ?? 'false'}'), trailing: IconButton(icon: const Icon(Icons.delete_outline), onPressed: _busy ? null : () async {
      final id = (u['.id'] ?? '').toString();
      if (id.isEmpty) { _message('User ID မရရှိပါ'); return; }
      final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('Voucher ဖျက်မလား?'), content: Text('${u['name']} ကို ဖျက်မည်'), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('မဖျက်ပါ')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('ဖျက်မည်'))]));
      if (ok == true) { try { await _client!.deleteUser(id); await _refresh(); } catch (e) { _message('$e'); } }
    })))),
    if (_connected && _users.isEmpty) const Padding(padding: EdgeInsets.all(20), child: Text('Voucher မရှိသေးပါ')),
  ]));

  Widget _qrPage() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Voucher QR Codes', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    if (_created.isEmpty) const Text('ဒီ App မှာ ယခု session အတွင်း Voucher မထုတ်ရသေးပါ။ Voucher tab မှာ အရင်ထုတ်ပါ။'),
    ..._created.map((v) => Card(child: ListTile(leading: QrImageView(data: 'WIFI_CODE_PRO|${v.username}|${v.password}', size: 64), title: Text(v.username), subtitle: const Text('Username / Password တူညီသည်'), onTap: () => showDialog<void>(context: context, builder: (ctx) => AlertDialog(title: const Text('Voucher QR'), content: Column(mainAxisSize: MainAxisSize.min, children: [QrImageView(data: 'WIFI_CODE_PRO|${v.username}|${v.password}', size: 190), Text('Username: ${v.username}'), Text('Password: ${v.password}')]), actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('ပိတ်မည်'))]))))),
  ]);

  Widget _routerPage() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('MikroTik Router ချိတ်ဆက်ရန်', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    const Text('RouterOS REST API ကို အသုံးပြုပါမည်။ User Manager voucher များကို Router ထဲသို့ တိုက်ရိုက်ထည့်ပေးသည်။'),
    const SizedBox(height: 14),
    TextField(controller: _host, decoration: const InputDecoration(labelText: 'Router IP / Host', hintText: '192.168.1.1', border: OutlineInputBorder())),
    const SizedBox(height: 10),
    TextField(controller: _user, decoration: const InputDecoration(labelText: 'RouterOS Username', border: OutlineInputBorder())),
    const SizedBox(height: 10),
    TextField(controller: _password, obscureText: !_showPassword, decoration: InputDecoration(labelText: 'RouterOS Password', border: const OutlineInputBorder(), suffixIcon: IconButton(onPressed: () => setState(() => _showPassword = !_showPassword), icon: Icon(_showPassword ? Icons.visibility_off : Icons.visibility)))),
    SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('HTTPS သုံးမည်'), subtitle: const Text('Router မှာ HTTPS certificate တပ်ဆင်ပြီးမှ ဖွင့်ပါ'), value: _https, onChanged: (v) => setState(() => _https = v)),
    FilledButton.icon(onPressed: _busy ? null : _connect, icon: const Icon(Icons.link), label: Text(_busy ? 'ချိတ်ဆက်နေသည်...' : 'Test & Connect')),
    const SizedBox(height: 12),
    Text(_connectionMessage, style: TextStyle(color: _connected ? Colors.green : Colors.orange)),
    if (_connected) Card(child: ListTile(leading: const Icon(Icons.router), title: Text('${_resource['board-name'] ?? 'MikroTik'}'), subtitle: Text('RouterOS ${_resource['version'] ?? ''}  •  Uptime ${_resource['uptime'] ?? ''}'))),
    const SizedBox(height: 12),
    const Text('လုံခြုံရေး: HTTP သည် Password ကို စာသားဖတ်နိုင်သည့်ပုံစံဖြင့် ပို့သည်။ အိမ်/ဆိုင်၏ ယုံကြည်ရသော LAN ထဲတွင်သာ စမ်းသပ်ပါ။ အင်တာနက်မှ တိုက်ရိုက်ဖွင့်မထားပါနှင့်။ အဝေးမှအသုံးပြုရန် VPN နှင့် HTTPS သုံးပါ။ Dedicated RouterOS account တစ်ခုဖန်တီးပြီး လိုအပ်သည့် read/write/api/rest-api permission များသာပေးပါ။', style: TextStyle(color: Colors.deepOrange)),
  ]);

  Widget _reportPage() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Reports', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
    const SizedBox(height: 12),
    ListTile(leading: const Icon(Icons.confirmation_number), title: const Text('Total vouchers'), trailing: Text('${_users.length}')),
    ListTile(leading: const Icon(Icons.people), title: const Text('Active Hotspot sessions'), trailing: Text('${_sessions.length}')),
    ListTile(leading: const Icon(Icons.account_tree), title: const Text('User Manager profiles'), trailing: Text('${_profiles.length}')),
    const Text('Sales report ကို QR Payment Provider ချိတ်ဆက်ပြီးမှ တွက်ချက်နိုင်ပါမည်။'),
  ]);
}

class VoucherCreator extends StatefulWidget {
  const VoucherCreator({super.key, required this.connected, required this.busy, required this.profiles, required this.onCreate, required this.created});
  final bool connected;
  final bool busy;
  final List<Map<String, dynamic>> profiles;
  final Future<void> Function(int, String?) onCreate;
  final List<VoucherRecord> created;
  @override
  State<VoucherCreator> createState() => _VoucherCreatorState();
}

class _VoucherCreatorState extends State<VoucherCreator> {
  int _count = 10;
  String? _profile;
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Voucher ထုတ်ရန်', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    Text(widget.connected ? 'Router ချိတ်ဆက်ပြီးပါပြီ' : 'Router မချိတ်ရသေးပါ — Router tab မှာ ချိတ်ပါ'),
    const SizedBox(height: 16),
    const Text('Voucher အရေအတွက်'),
    const SizedBox(height: 6),
    SegmentedButton<int>(segments: const [ButtonSegment(value: 10, label: Text('10')), ButtonSegment(value: 25, label: Text('25')), ButtonSegment(value: 50, label: Text('50')), ButtonSegment(value: 100, label: Text('100'))], selected: {_count}, onSelectionChanged: (s) => setState(() => _count = s.first)),
    const SizedBox(height: 16),
    const Text('User Manager Profile (optional)'),
    const SizedBox(height: 6),
    DropdownButtonFormField<String?>(value: _profile, decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'Profile မရွေးပါ'), items: [const DropdownMenuItem<String?>(value: null, child: Text('Profile မရွေးပါ')), ...widget.profiles.map((p) => DropdownMenuItem<String?>(value: p['name']?.toString(), child: Text(p['name']?.toString() ?? '')))], onChanged: (v) => setState(() => _profile = v)),
    const SizedBox(height: 16),
    FilledButton.icon(onPressed: widget.connected && !widget.busy ? () => widget.onCreate(_count, _profile) : null, icon: const Icon(Icons.add_card), label: Text(widget.busy ? 'လုပ်ဆောင်နေသည်...' : '$_count ခု Voucher ထုတ်မည်')),
    const SizedBox(height: 10),
    const Text('Username နှင့် Password ကို ၆ လုံးကျပန်းနံပါတ်ဖြင့် တူညီစွာ ထုတ်ပေးမည်။ Profile မရွေးလျှင် သက်တမ်း/အမြန်နှုန်း ကန့်သတ်ချက် မသတ်မှတ်ပါ။'),
    const SizedBox(height: 20),
    const Text('ယခုထုတ်ထားသော Voucher', style: TextStyle(fontWeight: FontWeight.bold)),
    ...widget.created.take(30).map((v) => ListTile(dense: true, leading: const Icon(Icons.confirmation_number), title: Text(v.username), subtitle: Text('Password: ${v.password}'))),
  ]);
}
